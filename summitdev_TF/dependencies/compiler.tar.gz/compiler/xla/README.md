<p align="center">
  <img width="200" src="xlalogo.png"/>
</p>

XLA (Accelerated Linear Algebra) is a domain-specific compiler for linear
algebra that optimizes TensorFlow computations. See the
[documentation](https://www.tensorflow.org/performance/xla/) for more details.
